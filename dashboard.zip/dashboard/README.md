# Mi Panel · Christian

Dashboard de vida + curso 35mm con sincronización en la nube.

---

## 1. Crear base de datos en Supabase (gratis, 5 min)

1. Ve a **supabase.com** → New project
2. Ponle nombre (ej. "mi-panel"), elige contraseña y región Europe
3. Espera que termine de crear (1-2 min)
4. Ve a **SQL Editor** y ejecuta esto:

```sql
create table if not exists projects (
  id bigint primary key,
  data jsonb not null,
  created_at timestamptz default now()
);

alter table projects enable row level security;

create policy "Allow all" on projects
  for all using (true) with check (true);
```

5. Ve a **Settings → API** y copia:
   - **Project URL** → `https://xxxx.supabase.co`
   - **anon public** key → `eyJhbGci...`

---

## 2. Publicar en GitHub Pages (gratis, 10 min)

1. Crea cuenta en **github.com** si no tienes
2. New repository → nombre: `mi-panel` → Public
3. Sube los archivos: `index.html`, `manifest.json`, `sw.js`, los dos PNG de iconos
4. Ve a Settings → Pages → Branch: main → Save
5. Tu app estará en: `https://TU_USUARIO.github.io/mi-panel`

---

## 3. Registrar el Service Worker

Añade esto al final del `<body>` en index.html (ya incluido):

```html
<script>
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}
</script>
```

---

## 4. Instalar como app nativa

### Mac (Safari)
1. Abre la URL de GitHub Pages en Safari
2. Menú Archivo → Compartir → Añadir al Dock

### iPhone (Safari)
1. Abre la URL en Safari
2. Botón compartir → Añadir a pantalla de inicio

### Chrome (Mac/Windows/Android)
1. Abre la URL en Chrome
2. Aparece botón "Instalar" en la barra de dirección
3. O: Menú ⋮ → Instalar aplicación

---

## 5. Configurar sincronización

Al abrir la app por primera vez:
1. Aparece banner azul → pega tu URL y key de Supabase
2. Haz clic en "Conectar y sincronizar"
3. Los datos se sincronizan automáticamente cada 30 segundos

---

## Notas

- Los datos se guardan tanto en la nube (Supabase) como localmente (offline)
- Si no hay conexión, la app funciona igual y sincroniza cuando vuelve internet
- El curso 35mm está fijo en el código (tareas, notas, feedback del profesor)
- Los proyectos de vida son editables y se sincronizan en tiempo real

---

## Estructura de archivos

```
dashboard/
├── index.html      ← App completa
├── manifest.json   ← Config PWA
├── sw.js           ← Service worker (offline)
├── icon-192.png    ← Icono app (generar con cualquier editor)
└── icon-512.png    ← Icono app grande
```

Para los iconos puedes usar cualquier imagen tuya de 192x192 y 512x512 píxeles en PNG.
